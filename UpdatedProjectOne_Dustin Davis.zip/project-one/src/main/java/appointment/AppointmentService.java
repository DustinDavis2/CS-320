package appointment;

// Author Dustin Davis

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	
	private Map<String, Appointment> appointments = new HashMap<>();
	
	public void addAppointment(Appointment appointment) {
		if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment must be non-null and ID must be unique");
		}
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	
	public void deleteAppointment(String appointmentId) {
		if (appointmentId == null || !appointments.containsKey(appointmentId)) {
			throw new IllegalArgumentException("Invalid appointment ID");
		}
		appointments.remove(appointmentId);
	}
	
	public Appointment getAppointment(String appointmentId) {
		return appointments.get(appointmentId);
	}

}
