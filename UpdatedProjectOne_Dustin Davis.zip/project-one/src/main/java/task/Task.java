package task;

/**
 * The Task class defines a task with a unique ID, a name, and a description.
 * It enforces strict validation on all fields to ensure data integrity.
 */

public class Task {
	// Task ID: unique, non-null, max 10 characters, not updatable
	private final String taskId;
	
	// Task name: non-null, max 20 characters
	private String name;
	
	// Task description: non-null, max 50 characters
	private String description;
	
	/**
	 * Constructs a new Task with the specified ID, name, and description.
	 * Validates input according to defined business rules.
	 * 
	 * @param taskId  Unique identifier for the task
	 * @param name  Name of the task
	 * @param description  Description of the task
	 * @throws IllegalArgumentsException if any field is null or too long
	 */
	
	public Task(String taskId, String name, String description) {
		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid task ID");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid task name");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid task description");
		}
		
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}
	
	/**
	 * Gets the task ID.
	 * This value is set once during creation and cannot be changed.
	 * 
	 * @return Task ID string
	 */
	
	public String getTaskId() {
		return taskId;
	}
	
	/**
	 * Gets the name of the task.
	 * 
	 * @return Task name string
	 */
	
	public String getName() {
		return name;
	}
	
	/**
	 * Gets the description of the task.
	 * 
	 * @return Task description string
	 */
	
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets a new name for the task.
	 * 
	 * @param name New name string
	 * @throws IllegalArgumentException if name is null or too long
	 */
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid task name");
		}
		this.name = name;
	}
	
	/**
	 * Sets a new description for the task.
	 * 
	 * @param description New description string
	 * @throws IllegalArgumentException if description is null or too long
	 */
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid task description");
		}
		this.description = description;
	}

}
