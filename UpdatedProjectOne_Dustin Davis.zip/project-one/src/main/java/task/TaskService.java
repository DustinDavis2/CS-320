package task;

import java.util.HashMap;
import java.util.Map;

/**
 * TaskService manages a collection of Task objects in memory.
 * It supports adding, deleting, and updating tasks by their ID.
 */

public class TaskService {
	
	// In-memory storage for tasks using task ID as the key
	private Map<String, Task> taskMap = new HashMap<>();
	
	/**
	 * Adds a new task to the service if the task ID is unique.
	 * 
	 * @param task The task to add
	 * @throws IllegalArgumentException if the task ID already exists
	 */
	
	public void addTask(Task task) {
		if (taskMap.containsKey(task.getTaskId())) {
			throw new IllegalArgumentException("Task ID must be unique");
		}
		taskMap.put(task.getTaskId(), task);
	}
	
	/**
	 * Deletes a task from the service by its ID.
	 * 
	 * @param taskId the ID of the task to remove
	 * @throws IllegalArgumentException if the task ID is not found
	 */
	
	public void deleteTask(String taskId) {
		if (!taskMap.containsKey(taskId)) {
			throw new IllegalArgumentException("Task ID not found");
		}
		taskMap.remove(taskId);
	}
	
	/**
	 * Updates the name of a task identified by its ID.
	 * 
	 * @param taskId the ID of the task to update
	 * @param newName the new name value
	 * @throws IllegalArgumentException if the task ID is not found
	 */
	
	public void updateTaskName(String taskId, String newName) {
		Task task = taskMap.get(taskId);
		if (task == null) {
			throw new IllegalArgumentException("Task ID not found");
		}
		task.setName(newName);
	}
	
	/**
	 * Updates the description of a task identified by its ID.
	 * 
	 * @param taskId  The ID of the task to update
	 * @param newDescription  The new description value
	 * @throws IllegalArgumentException if the task ID is not found
	 */
	
	public void updateTaskDescription(String taskId, String newDescription) {
		Task task = taskMap.get(taskId);
		if (task == null) {
			throw new IllegalArgumentException("Task ID not found");
		}
		task.setDescription(newDescription);
	}
	
	/**
	 * Returns the task with the given ID.
	 * Used for verification in testing.
	 * 
	 * @param taskId the ID of the task to retrieve
	 * @return Task object if found, or null
	 */
	
	public Task getTask(String taskId) {
		return taskMap.get(taskId);
	}
}
