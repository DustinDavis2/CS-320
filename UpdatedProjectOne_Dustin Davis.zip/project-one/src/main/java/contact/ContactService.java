package contact;


import java.util.Map;
import java.util.HashMap;

/*
 * Author: Dustin Davis
 * Date: 7/15/25
 * Class: CS-320
 * Description: ContactService.java handles storing and managing contact objects
 * in memory, including operations to add, delete, and update them.
 */

public class ContactService {
	
	// List to hold all contacts
	private Map<String, Contact> contacts = new HashMap<>();
	
	// Add a contact if the ID is unique
	public boolean addContact(Contact contact) {
		for (Contact existing : contacts.values()) {
			if (existing.getContactId().equals(contact.getContactId())) {
				throw new IllegalArgumentException("Duplicate contact ID");
			}
		}
		contacts.put(contact.getContactId(), contact);
		return true;
	}
	
	// Delete a contact by ID
	public boolean deleteContact(String contactId) {
		if (!contacts.containsKey(contactId)) {
			return false;
		}
		contacts.remove(contactId);
		return true;
	}
	
	// Update first name by contact ID
	public boolean updateFirstName(String contactId, String firstName) {
		for (Contact c : contacts.values()) {
			if (c.getContactId().equals(contactId)) {
				c.setFirstName(firstName);
				return true;
			}
		}
		return false;
	}
	
	// Update last name by contact ID
	public boolean updateLastName(String contactId, String lastName) {
		for (Contact c : contacts.values()) {
			if (c.getContactId().equals(contactId)) {
				c.setLastName(lastName);
				return true;
			}
		}
		return false;
	}
	
	// Update phone number by contact ID
	public boolean updatePhone(String contactId, String phone) {
		for (Contact c : contacts.values()) {
			if (c.getContactId().equals(contactId)) {
				c.setPhone(phone);
				return true;
			}
		}
		return false;
	}
	
	// Update address by contact ID
	public boolean updateAddress(String contactId, String address) {
		for (Contact c : contacts.values()) {
			if (c.getContactId().equals(contactId)) {
				c.setAddress(address);
				return true;
			}
		}
		return false;
	}
	
	// Method to retrieve a contact by ID
	public Contact getContact(String contactId) {
		if (!contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		return contacts.get(contactId);
	}

}
