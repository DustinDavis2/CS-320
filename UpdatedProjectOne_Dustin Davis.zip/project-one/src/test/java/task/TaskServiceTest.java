package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the TaskServiceclass.
 * These tests verify add, delete, and update functionality.
 */

public class TaskServiceTest {
	
	private TaskService service;
	
	@BeforeEach
	public void setup() {
		service = new TaskService();
	}
	
	@Test
	public void testAddTaskSuccessfully() {
		Task task = new Task("001", "Do Laundry", "Wash clothes this evening.");
		service.addTask(task);
		assertEquals("Do Laundry", service.getTask("001").getName());
	}
	
	@Test
	public void testAddTaskWithDuplicateIdThrowsException() {
		Task task1 = new Task("001", "One", "First task");
		Task task2 = new Task("001", "Two", "Duplicate ID");
		service.addTask(task1);
		assertThrows(IllegalArgumentException.class, () -> {
			service.addTask(task2);
		});
	}
	
	@Test
	public void testDeleteTaskSuccessfully() {
		Task task = new Task("002", "Clean", "Clean the kitchen");
		service.addTask(task);
		service.deleteTask("002");
		assertNull(service.getTask("002"));
	}
	
	@Test
	public void testDeleteNonExistentTaskThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteTask("999");
		});
	}
	
	@Test
	public void testUpdateTaskNameSuccessfully() {
		Task task = new Task("003", "Old Name", "Desc");
		service.addTask(task);
		service.updateTaskName("003", "New Name");
		assertEquals("New Name", service.getTask("003").getName());
	}
	
	@Test
	public void testUpdateTaskDescriptionSuccessfully() {
		Task task = new Task("004", "Name", "Old Desc");
		service.addTask(task);
		service.updateTaskDescription("004","Updated description");
		assertEquals("Updated description", service.getTask("004").getDescription());
	}
	
	@Test
	public void testUpdateNameOnNonExistentTaskThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.updateTaskName("999", "Test");
		});
	}
	
	@Test
	public void testUpdateDescriptionOnNonExistentTaskThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.updateTaskDescription("999", "Test");
		});
	}
}
