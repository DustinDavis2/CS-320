package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Task class to verify validation rules and data handling.
 */

public class TaskTest {
	
	@Test
	public void testValidTaskCreation() {
		Task task = new Task("123", "Buy Milk", "Remember to buy milk today.");
		assertEquals("123", task.getTaskId());
		assertEquals("Buy Milk", task.getName());
		assertEquals("Remember to buy milk today.", task.getDescription());
	}
	
	@Test
	public void testNullTaskIdThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Name", "Desc");
		});
	}
	
	@Test
	public void testLongTaskIdThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678901", "Name", "Desc"); // 11 characters
		});
	}
	
	@Test
	public void testNullNameThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", null, "Desc");
		});
	}
	
	@Test
	public void testLongNameThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "This name is way too long to be valid", "Desc");
		});
	}
	
	@Test
	public void testNullDescriptionThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Name", null);
		});
	}
	
	@Test
	public void testLongDescriptionThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Name", "This description is way too long and definitely goes over fifty characters.");
		});
	}
	
	@Test
	public void testUpdateNameValid() {
		Task task = new Task("123", "Old Name", "Desc");
		task.setName("New Name");
		assertEquals("New Name", task.getName());
	}
	
	@Test
	public void testUpdateDescriptionValid() {
		Task task = new Task("123", "Name", "Old Desc");
		task.setDescription("New description goes here.");
		assertEquals("New description goes here.", task.getDescription());
	}
	
	@Test
	public void testUpdateNameInvalid() {
		Task task = new Task("123", "Valid Name", "Desc");
		assertThrows(IllegalArgumentException.class, () -> {
			task.setName(null);
		});
		assertThrows(IllegalArgumentException.class, () -> {
			task.setName("This name is more than twenty characters long");
		});
	}
	
	@Test
	public void testUpdateDescriptionInvalid() {
		Task task = new Task("123", "Name", "Valid Desc");
		assertThrows(IllegalArgumentException.class, () -> {
			task.setDescription(null);
		});
		assertThrows(IllegalArgumentException.class, () -> {
			task.setDescription("This description is definitely more than fifty characters long and should fail");
		});
	}
}
