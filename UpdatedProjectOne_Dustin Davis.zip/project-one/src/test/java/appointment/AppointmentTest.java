package appointment;

// Author Dustin Davis

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
	
	// Helper to get a future date
	private Date getFutureDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);  // Tomorrow
		return cal.getTime();
	}
	
	@Test
	public void testValidAppointmentCreation() {
		Appointment appt = new Appointment("A123", getFutureDate(), "Checkup");
		assertEquals("A123", appt.getAppointmentId());
		assertEquals("Checkup", appt.getDescription());
		assertNotNull(appt.getAppointmentDate());
	}
	
	@Test
	public void testAppointmentIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("ABCDEFGHIJK", getFutureDate(), "Description");
		});
	}
	
	@Test
	public void testNullAppointmentId() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, getFutureDate(), "Description");
		});
	}
	
	@Test
	public void testPastAppointmentDate() {
		Date pastDate = new Date(System.currentTimeMillis() - 1000);  // 1 second in the past
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("A123", pastDate, "Description");
		});
	}
	
	@Test
	public void testNullAppointmentDate() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("A123", null, "Description");
		});
	}
	
	@Test
	public void testDescriptionTooLong() {
		String longDesc = "This description is definitely way longer than fifty characters.";
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("A123", getFutureDate(), longDesc);
		});
	}
	
	@Test
	public void testNullDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("A123", getFutureDate(), null);
		});
	}
	
	@Test
	public void testSetValidDescription() {
		Appointment appt = new Appointment("A123", getFutureDate(), "Initial");
		appt.setDescription("Updated description");
		assertEquals("Updated description", appt.getDescription());
	}
	
	@Test
	public void testSetInvalidDescription() {
		Appointment appt = new Appointment("A123", getFutureDate(), "Initial");
		assertThrows(IllegalArgumentException.class, () -> {
			appt.setDescription(null);
		});
	}
	
	@Test
	public void testSetValidFutureDate() {
		Appointment appt = new Appointment("A123", getFutureDate(), "Initial");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 2);
		Date newDate = cal.getTime();
		appt.setAppointmentDate(newDate);
		assertEquals(newDate, appt.getAppointmentDate());
	}
	
	@Test
	public void testSetInvalidPastDate() {
		Appointment appt = new Appointment("A123", getFutureDate(), "Initial");
		Date past = new Date(System.currentTimeMillis() - 5000);
		assertThrows(IllegalArgumentException.class, () -> {
			appt.setAppointmentDate(past);
		});
	}

}
