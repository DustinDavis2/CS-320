package appointment;

// Author Dustin Davis

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
	
	private AppointmentService service;
	private Date futureDate;
	
	@BeforeEach
	public void setUp() {
		service = new AppointmentService();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		futureDate = cal.getTime();
	}
	
	@Test
	public void testAddValidAppointment() {
		Appointment appt = new Appointment("A1", futureDate, "Dentist visit");
		service.addAppointment(appt);
		assertEquals(appt, service.getAppointment("A1"));
	}
	
	@Test
	public void testAddDuplicateIdFails() {
		Appointment appt1 = new Appointment("A1", futureDate, "Dentist");
		Appointment appt2 = new Appointment("A1", futureDate, "Doctor");
		service.addAppointment(appt1);
		assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appt2);
		});
	}
	
	@Test
	public void testAddNullAppointmentFails() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(null);
		});
	}
	
	@Test
	public void testDeleteAppointment() {
		Appointment appt = new Appointment("A1", futureDate, "Meeting");
		service.addAppointment(appt);
		service.deleteAppointment("A1");
		assertNull(service.getAppointment("A1"));
	}
	
	@Test
	public void testDeleteNonexistentAppointmentFails() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment("NonExistent");
		});
	}
	
	@Test
	public void testDeleteNullIdFails() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment(null);
		});
	}

}
