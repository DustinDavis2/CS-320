/*
 * Author: Dustin Davis
 * Date: 7/15/25
 * Class: CS-320
 * Description: Unit tests for the ContactService class. Verifies the ability to
 * add, delete, and update contact objects using the ContactService.
 */
package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	private ContactService service;
	
	// Set up a fresh ContactService before each test
	@BeforeEach
	public void setUp() {
		service = new ContactService();
	}
	
	@Test
	public void testAddContact() {
		Contact contact = new Contact("ID01", "John", "Doe", "1234567890", "123 Main St");
		service.addContact(contact);
		assertEquals(contact, service.getContact("ID01"));
	}
	
	@Test
	public void testDeleteContact() {
		Contact contact = new Contact("ID02", "Jane", "Smith", "0987654321", "456 Oak Ave");
		service.addContact(contact);
		service.deleteContact("ID02");
		assertThrows(IllegalArgumentException.class, () -> {
			service.getContact("ID02");
		});
	}
	
	@Test
	public void testUpdateFirstName() {
		Contact contact = new Contact("ID03", "Mike", "Tyson", "5555555555", "789 Pine Ln");
		service.addContact(contact);
		service.updateFirstName("ID03", "Max");
		assertEquals("Max", service.getContact("ID03").getFirstName());
	}
	
	@Test
	public void testUpdateLastName() {
		Contact contact = new Contact("ID04", "Alice", "Wonder", "1111111111", "111 Rabbit Rd");
		service.addContact(contact);
		service.updateLastName("ID04", "Walker");
		assertEquals("Walker", service.getContact("ID04").getLastName());
	}
	
	@Test
	public void testUpdatePhone() {
		Contact contact = new Contact("ID05", "Bob", "Builder", "2222222222", "222 Tool St");
		service.addContact(contact);
		service.updatePhone("ID05", "3333333333");
		assertEquals("3333333333", service.getContact("ID05").getPhone());
	}
	
	@Test
	public void testUpdateAddress() {
		Contact contact = new Contact("ID06", "Tom", "Jerry", "4444444444", "444 Cat Ave");
		service.addContact(contact);
		service.updateAddress("ID06", "555 Mouse Ln");
		assertEquals("555 Mouse Ln", service.getContact("ID06").getAddress());
	}
	
	@Test
	public void testAddDuplicateContactIdFails() {
		Contact contact1 = new Contact("ID07", "First", "User", "6666666666","Street One");
		Contact contact2 = new Contact("ID07", "Second", "User", "7777777777", "Street Two");
		service.addContact(contact1);
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		});
	}

}
