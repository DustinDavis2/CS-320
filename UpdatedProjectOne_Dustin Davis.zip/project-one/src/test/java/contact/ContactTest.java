/*
 * Author: Dustin Davis
 * Date: 7/15/25
 * Class: CS-320
 * Description: ContactTest.java uses JUnit to test validation and 
 * behavior of the Contact class.
 */
package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	@Test
	public void testValidContactCreation() {
		Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
		assertEquals("001", contact.getContactId());
		assertEquals("John", contact.getFirstName());
		assertEquals("Doe", contact.getLastName());
		assertEquals("1234567890", contact.getPhone());
		assertEquals("123 Main St", contact.getAddress());
	}
	
	@Test
	public void testInvalidContactId() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "John", "Doe", "1234567890", "123 Main St");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
		});
	}
	
	@Test
	public void testInvalidFirstName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("002", null, "Doe", "1234567890", "123 Main St");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("002", "ThisIsTooLong", "Doe", "1234567890", "123 Main St");
		});
	}
	
	@Test
	public void testInvalidLastName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("003", "John", null, "1234567890", "123 Main St");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("003", "John", "LastNameTooLong", "1234567890", "123 Main St");
		});
	}
	
	@Test
	public void testInvalidPhone() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("004", "John", "Doe", null, "123 Main St");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("004", "John", "Doe", "12345", "123 Main St");
		});
	}
	
	@Test
	public void testInvalidAddress() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("005", "John", "Doe", "1234567890", null);
		});
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("005", "John", "Doe", "1234567890", "1234567890 Wow this is a big street. This address is too long");
		});
	}
	
	@Test
	public void testSetters() {
		Contact contact = new Contact("006", "Jane", "Smith", "0987654321", "456 Oak St");
		
		contact.setFirstName("Emily");
		assertEquals("Emily", contact.getFirstName());
		
		contact.setLastName("Jones");
		assertEquals("Jones", contact.getLastName());
		
		contact.setPhone("1122334455");
		assertEquals("1122334455", contact.getPhone());
		
		contact.setAddress("789 Pine St");
		assertEquals("789 Pine St", contact.getAddress());
	}
	
	@Test
	public void testSetInvalidFirstName() {
	    Contact contact = new Contact("007", "Jane", "Doe", "1234567890", "Main St");
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setFirstName(null);
	    });
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setFirstName("NameThatIsWayTooLong");
	    });
	}

	@Test
	public void testSetInvalidLastName() {
	    Contact contact = new Contact("008", "Jane", "Doe", "1234567890", "Main St");
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setLastName(null);
	    });
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setLastName("LastNameTooLong");
	    });
	}

	@Test
	public void testSetInvalidPhone() {
	    Contact contact = new Contact("009", "Jane", "Doe", "1234567890", "Main St");
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setPhone(null);
	    });
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setPhone("123");  // Too short
	    });
	}

	@Test
	public void testSetInvalidAddress() {
	    Contact contact = new Contact("010", "Jane", "Doe", "1234567890", "Main St");
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setAddress(null);
	    });
	    assertThrows(IllegalArgumentException.class, () -> {
	        contact.setAddress("This address is way too long and definitely over 30 characters");
	    });
	}
}
